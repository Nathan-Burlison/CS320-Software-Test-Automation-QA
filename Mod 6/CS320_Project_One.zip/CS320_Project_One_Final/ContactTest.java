import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * Tests the Contact class with both acceptable and unacceptable input.
 *
 * The goal is to make sure valid data is saved correctly and bad input is
 * caught instead of being allowed into the object.
 */
class ContactTest {

    // Make sure normal contact information is stored correctly.
    @Test
    void testContactCreation() {
        Contact contact = new Contact(
                "1234567890",
                "John",
                "Smith",
                "8015551234",
                "123 Main Street");

        assertEquals("1234567890", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Smith", contact.getLastName());
        assertEquals("8015551234", contact.getPhone());
        assertEquals("123 Main Street", contact.getAddress());
    }

    // Check the exact boundary values instead of only shorter examples.
    @Test
    void testContactAcceptsMaximumLengthValues() {
        Contact contact = new Contact(
                "1234567890",
                "ABCDEFGHIJ",
                "KLMNOPQRST",
                "0123456789",
                "123456789012345678901234567890");

        assertEquals(10, contact.getContactId().length());
        assertEquals(10, contact.getFirstName().length());
        assertEquals(10, contact.getLastName().length());
        assertEquals(10, contact.getPhone().length());
        assertEquals(30, contact.getAddress().length());
    }

    // A contact should not be created without an ID.
    @Test
    void testContactIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact(
                        null, "John", "Smith",
                        "8015551234", "123 Main Street"));
    }

    // Try one character past the ID limit.
    @Test
    void testContactIdCannotBeLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact(
                        "12345678901", "John", "Smith",
                        "8015551234", "123 Main Street"));
    }

    // A missing first name should fail validation.
    @Test
    void testFirstNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact(
                        "1", null, "Smith",
                        "8015551234", "123 Main Street"));
    }

    // Make sure an oversized first name is not accepted.
    @Test
    void testFirstNameCannotBeLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact(
                        "1", "Christopher", "Smith",
                        "8015551234", "123 Main Street"));
    }

    // A missing last name should fail validation.
    @Test
    void testLastNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact(
                        "1", "John", null,
                        "8015551234", "123 Main Street"));
    }

    // Make sure an oversized last name is not accepted.
    @Test
    void testLastNameCannotBeLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact(
                        "1", "John", "Longlastname",
                        "8015551234", "123 Main Street"));
    }

    // The phone field cannot be left empty.
    @Test
    void testPhoneCannotBeNull() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact(
                        "1", "John", "Smith",
                        null, "123 Main Street"));
    }

    // Exercise the main ways a phone number can fail validation.
    @Test
    void testPhoneMustBeExactlyTenDigits() {
        // Fewer than 10 digits.
        assertThrows(IllegalArgumentException.class,
                () -> new Contact(
                        "1", "John", "Smith",
                        "801555123", "123 Main Street"));

        // More than 10 digits.
        assertThrows(IllegalArgumentException.class,
                () -> new Contact(
                        "1", "John", "Smith",
                        "80155512345", "123 Main Street"));

        // Includes a letter instead of a digit.
        assertThrows(IllegalArgumentException.class,
                () -> new Contact(
                        "1", "John", "Smith",
                        "80155A1234", "123 Main Street"));
    }

    // The address field should not accept a null value.
    @Test
    void testAddressCannotBeNull() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact(
                        "1", "John", "Smith",
                        "8015551234", null));
    }

    // Check the address limit with a value that is one character too long.
    @Test
    void testAddressCannotBeLongerThanThirtyCharacters() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact(
                        "1", "John", "Smith",
                        "8015551234",
                        "1234567890123456789012345678901"));
    }

    // Confirm that each editable field can be changed with valid data.
    @Test
    void testSettersUpdateValidFields() {
        Contact contact = new Contact(
                "1", "John", "Smith",
                "8015551234", "123 Main Street");

        contact.setFirstName("Johnny");
        contact.setLastName("Johnson");
        contact.setPhone("3855559999");
        contact.setAddress("456 Oak Avenue");

        assertEquals("Johnny", contact.getFirstName());
        assertEquals("Johnson", contact.getLastName());
        assertEquals("3855559999", contact.getPhone());
        assertEquals("456 Oak Avenue", contact.getAddress());
    }

    // Updating a field should use the same validation as object creation.
    @Test
    void testSettersRejectInvalidValues() {
        Contact contact = new Contact(
                "1", "John", "Smith",
                "8015551234", "123 Main Street");

        assertThrows(IllegalArgumentException.class,
                () -> contact.setFirstName(null));
        assertThrows(IllegalArgumentException.class,
                () -> contact.setLastName("12345678901"));
        assertThrows(IllegalArgumentException.class,
                () -> contact.setPhone("555"));
        assertThrows(IllegalArgumentException.class,
                () -> contact.setAddress(
                        "1234567890123456789012345678901"));
    }
}
