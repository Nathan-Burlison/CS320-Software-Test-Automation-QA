import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.Test;

/**
 * Checks the Appointment object with valid values and common invalid cases.
 */
class AppointmentTest {

    // Creates a reusable date so the tests do not depend on a hard-coded year.
    private Date dateFromToday(int days) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, days);
        return calendar.getTime();
    }

    @Test
    void testAppointmentCreation() {
        // Confirm that valid appointment data is saved correctly.
        Date futureDate = dateFromToday(1);

        Appointment appointment = new Appointment(
                "12345",
                futureDate,
                "Annual vehicle inspection");

        assertEquals("12345", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals(
                "Annual vehicle inspection",
                appointment.getDescription());
    }

    @Test
    void testAppointmentAcceptsMaximumLengthValues() {
        // Use the exact allowed limits for the ID and description.
        Date futureDate = dateFromToday(1);

        Appointment appointment = new Appointment(
                "1234567890",
                futureDate,
                "12345678901234567890123456789012345678901234567890");

        assertEquals(10, appointment.getAppointmentId().length());
        assertEquals(50, appointment.getDescription().length());
    }

    @Test
    void testAppointmentIdCannotBeNull() {
        // A missing ID should prevent the appointment from being created.
        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        null,
                        dateFromToday(1),
                        "Annual vehicle inspection"));
    }

    @Test
    void testAppointmentIdCannotBeLongerThanTenCharacters() {
        // Check the ID rule with a value just over the limit.
        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        "12345678901",
                        dateFromToday(1),
                        "Annual vehicle inspection"));
    }

    @Test
    void testAppointmentDateCannotBeNull() {
        // An appointment cannot be scheduled without a date.
        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        "1",
                        null,
                        "Annual vehicle inspection"));
    }

    @Test
    void testAppointmentDateCannotBeInPast() {
        // Yesterday is used to verify that past dates are rejected.
        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        "1",
                        dateFromToday(-1),
                        "Annual vehicle inspection"));
    }

    @Test
    void testDescriptionCannotBeNull() {
        // A missing description should fail validation.
        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        "1",
                        dateFromToday(1),
                        null));
    }

    @Test
    void testDescriptionCannotBeLongerThanFiftyCharacters() {
        // Try a description that is one character beyond the limit.
        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        "1",
                        dateFromToday(1),
                        "123456789012345678901234567890123456789012345678901"));
    }
}
