/**
 * Holds the information for a single contact.
 *
 * Validation is handled here so invalid contact data is stopped before it can
 * be stored. The contact ID is kept final because it should stay the same for
 * the life of the object.
 */
public class Contact {
    // The ID is assigned once when the contact is created.
    private final String contactId;

    // These values can be changed later through the setter methods.
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    /**
     * Creates a contact after validating all required fields.
     *
     * @param contactId unique ID with a maximum of 10 characters
     * @param firstName first name with a maximum of 10 characters
     * @param lastName last name with a maximum of 10 characters
     * @param phone phone number containing exactly 10 digits
     * @param address address with a maximum of 30 characters
     * @throws IllegalArgumentException if any field violates a requirement
     */
    public Contact(String contactId, String firstName, String lastName,
                   String phone, String address) {
        // Check everything first so a partially valid contact is never created.
        validateContactId(contactId);
        validateFirstName(firstName);
        validateLastName(lastName);
        validatePhone(phone);
        validateAddress(address);

        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;
    }

    /**
     * @return the contact's unique ID
     */
    public String getContactId() {
        return contactId;
    }

    /**
     * @return the contact's first name
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @return the contact's last name
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @return the contact's 10-digit phone number
     */
    public String getPhone() {
        return phone;
    }

    /**
     * @return the contact's address
     */
    public String getAddress() {
        return address;
    }

    /**
     * Changes the first name after checking the new value.
     *
     * @param firstName new first name
     */
    public void setFirstName(String firstName) {
        validateFirstName(firstName);
        this.firstName = firstName;
    }

    /**
     * Changes the last name after checking the new value.
     *
     * @param lastName new last name
     */
    public void setLastName(String lastName) {
        validateLastName(lastName);
        this.lastName = lastName;
    }

    /**
     * Changes the phone number after checking the new value.
     *
     * @param phone new 10-digit phone number
     */
    public void setPhone(String phone) {
        validatePhone(phone);
        this.phone = phone;
    }

    /**
     * Changes the address after checking the new value.
     *
     * @param address new address
     */
    public void setAddress(String address) {
        validateAddress(address);
        this.address = address;
    }

    // Reject an ID that is missing or too long.
    private static void validateContactId(String contactId) {
        if (contactId == null || contactId.length() > 10) {
            throw new IllegalArgumentException(
                    "Contact ID cannot be null or longer than 10 characters.");
        }
    }

    // Keep first names within the allowed size.
    private static void validateFirstName(String firstName) {
        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException(
                    "First name cannot be null or longer than 10 characters.");
        }
    }

    // Keep last names within the allowed size.
    private static void validateLastName(String lastName) {
        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException(
                    "Last name cannot be null or longer than 10 characters.");
        }
    }

    // Accept only a full 10-digit number with no letters or symbols.
    private static void validatePhone(String phone) {
        if (phone == null || !phone.matches("\\d{10}")) {
            throw new IllegalArgumentException(
                    "Phone number must contain exactly 10 digits.");
        }
    }

    // Make sure an address is present and fits within the size limit.
    private static void validateAddress(String address) {
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException(
                    "Address cannot be null or longer than 30 characters.");
        }
    }
}
