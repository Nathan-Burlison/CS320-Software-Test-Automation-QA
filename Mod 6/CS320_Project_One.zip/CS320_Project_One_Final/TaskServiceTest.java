import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Tests the add, delete, and update features of TaskService.
 */
class TaskServiceTest {

    private TaskService service;
    private Task task;

    @BeforeEach
    void setUp() {
        // Start each test with clean service data.
        service = new TaskService();
        task = new Task(
                "1",
                "Pay Bills",
                "Pay the electric bill");
    }

    @Test
    void testAddTask() {
        service.addTask(task);

        assertSame(task, service.getTask("1"));
    }

    @Test
    void testAddTaskRequiresUniqueId() {
        service.addTask(task);

        Task duplicate = new Task(
                "1",
                "Clean Room",
                "Vacuum and organize the room");

        assertThrows(
                IllegalArgumentException.class,
                () -> service.addTask(duplicate));
    }

    @Test
    void testCannotAddNullTask() {
        assertThrows(
                IllegalArgumentException.class,
                () -> service.addTask(null));
    }

    @Test
    void testDeleteTask() {
        service.addTask(task);
        service.deleteTask("1");

        assertNull(service.getTask("1"));
    }

    @Test
    void testDeleteMissingTaskThrowsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> service.deleteTask("missing"));
    }

    @Test
    void testUpdateName() {
        service.addTask(task);
        service.updateName("1", "Grocery Shopping");

        assertEquals(
                "Grocery Shopping",
                service.getTask("1").getName());
    }

    @Test
    void testUpdateDescription() {
        service.addTask(task);
        service.updateDescription(
                "1",
                "Buy food for the week");

        assertEquals(
                "Buy food for the week",
                service.getTask("1").getDescription());
    }

    @Test
    void testUpdateMissingTaskThrowsException() {
        assertThrows(
                IllegalArgumentException.class,
                () -> service.updateName("missing", "New Name"));
    }

    @Test
    void testUpdateRejectsInvalidName() {
        service.addTask(task);

        assertThrows(
                IllegalArgumentException.class,
                () -> service.updateName(
                        "1",
                        "123456789012345678901"));
    }

    @Test
    void testUpdateRejectsInvalidDescription() {
        service.addTask(task);

        assertThrows(
                IllegalArgumentException.class,
                () -> service.updateDescription(
                        "1",
                        "123456789012345678901234567890123456789012345678901"));
    }

    @Test
    void testTaskIdDoesNotChangeAfterUpdates() {
        service.addTask(task);

        service.updateName("1", "Grocery Shopping");
        service.updateDescription("1", "Buy food for the week");

        assertEquals("1", service.getTask("1").getTaskId());
    }
}
