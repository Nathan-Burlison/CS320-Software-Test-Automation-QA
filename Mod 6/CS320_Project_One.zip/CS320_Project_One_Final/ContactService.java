import java.util.HashMap;
import java.util.Map;

/**
 * Manages contacts while the application is running.
 *
 * Contacts are kept in a HashMap, which makes it easy to look them up by ID.
 * This milestone only needs in-memory storage, so no database is used.
 */
public class ContactService {
    // Use the contact ID as the key for each stored contact.
    private final Map<String, Contact> contacts = new HashMap<>();

    /**
     * Adds a contact when its ID is not already in use.
     *
     * @param contact contact to add
     * @throws IllegalArgumentException if the contact is null or its ID exists
     */
    public void addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("Contact cannot be null.");
        }

        String contactId = contact.getContactId();

        // A duplicate key would break the unique-ID requirement.
        if (contacts.containsKey(contactId)) {
            throw new IllegalArgumentException(
                    "A contact with this ID already exists.");
        }

        contacts.put(contactId, contact);
    }

    /**
     * Deletes the contact associated with the supplied ID.
     *
     * @param contactId ID of the contact to delete
     * @throws IllegalArgumentException if the contact ID does not exist
     */
    public void deleteContact(String contactId) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID was not found.");
        }

        contacts.remove(contactId);
    }

    /**
     * Changes the first name for an existing contact.
     *
     * @param contactId ID of the contact to update
     * @param firstName new first name
     */
    public void updateFirstName(String contactId, String firstName) {
        getExistingContact(contactId).setFirstName(firstName);
    }

    /**
     * Changes the last name for an existing contact.
     *
     * @param contactId ID of the contact to update
     * @param lastName new last name
     */
    public void updateLastName(String contactId, String lastName) {
        getExistingContact(contactId).setLastName(lastName);
    }

    /**
     * Changes the phone number for an existing contact.
     *
     * @param contactId ID of the contact to update
     * @param phone new 10-digit phone number
     */
    public void updatePhone(String contactId, String phone) {
        getExistingContact(contactId).setPhone(phone);
    }

    /**
     * Changes the address for an existing contact.
     *
     * @param contactId ID of the contact to update
     * @param address new address
     */
    public void updateAddress(String contactId, String address) {
        getExistingContact(contactId).setAddress(address);
    }

    /**
     * Looks up a contact by ID.
     *
     * @param contactId ID to search for
     * @return the matching contact, or null if the ID is not stored
     */
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }

    /**
     * Finds an existing contact for an update operation.
     *
     * @param contactId ID of the contact to locate
     * @return the matching contact
     * @throws IllegalArgumentException if the ID does not exist
     */
    private Contact getExistingContact(String contactId) {
        Contact contact = contacts.get(contactId);

        if (contact == null) {
            throw new IllegalArgumentException("Contact ID was not found.");
        }

        return contact;
    }
}
