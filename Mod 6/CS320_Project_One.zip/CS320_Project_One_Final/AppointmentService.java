import java.util.HashMap;
import java.util.Map;

/**
 * Keeps track of appointments while the program is running.
 *
 * Appointments are stored in a HashMap so they can be found quickly by their
 * unique ID without needing a database.
 */
public class AppointmentService {
    // Each appointment is stored under its own appointment ID.
    private final Map<String, Appointment> appointments = new HashMap<>();

    /**
     * Saves a new appointment if its ID is not already in use.
     *
     * @param appointment appointment to add
     * @throws IllegalArgumentException if the appointment is null or duplicated
     */
    public void addAppointment(Appointment appointment) {
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment cannot be null.");
        }

        String appointmentId = appointment.getAppointmentId();

        // Stop duplicate IDs before adding the appointment to the map.
        if (appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException(
                    "An appointment with this ID already exists.");
        }

        appointments.put(appointmentId, appointment);
    }

    /**
     * Deletes the appointment connected to the supplied ID.
     *
     * @param appointmentId ID of the appointment to remove
     * @throws IllegalArgumentException if the ID is not stored
     */
    public void deleteAppointment(String appointmentId) {
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException(
                    "Appointment ID was not found.");
        }

        appointments.remove(appointmentId);
    }

    /**
     * Finds an appointment by its ID.
     *
     * @param appointmentId ID to look up
     * @return the matching appointment, or null if there is no match
     */
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}
