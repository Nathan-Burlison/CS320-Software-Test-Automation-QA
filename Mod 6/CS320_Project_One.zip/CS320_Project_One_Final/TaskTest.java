import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * Tests the Task class with valid, boundary, and invalid input.
 */
class TaskTest {

    @Test
    void testTaskCreation() {
        // Make sure normal task information is stored correctly.
        Task task = new Task(
                "12345",
                "Pay Bills",
                "Pay the electric and internet bills");

        assertEquals("12345", task.getTaskId());
        assertEquals("Pay Bills", task.getName());
        assertEquals(
                "Pay the electric and internet bills",
                task.getDescription());
    }

    @Test
    void testTaskAcceptsMaximumLengthValues() {
        // Check the exact limits instead of only shorter values.
        Task task = new Task(
                "1234567890",
                "12345678901234567890",
                "12345678901234567890123456789012345678901234567890");

        assertEquals(10, task.getTaskId().length());
        assertEquals(20, task.getName().length());
        assertEquals(50, task.getDescription().length());
    }

    @Test
    void testTaskIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task(null, "Pay Bills", "Pay the electric bill"));
    }

    @Test
    void testTaskIdCannotBeLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task(
                        "12345678901",
                        "Pay Bills",
                        "Pay the electric bill"));
    }

    @Test
    void testNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("1", null, "Pay the electric bill"));
    }

    @Test
    void testNameCannotBeLongerThanTwentyCharacters() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task(
                        "1",
                        "123456789012345678901",
                        "Pay the electric bill"));
    }

    @Test
    void testDescriptionCannotBeNull() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("1", "Pay Bills", null));
    }

    @Test
    void testDescriptionCannotBeLongerThanFiftyCharacters() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task(
                        "1",
                        "Pay Bills",
                        "123456789012345678901234567890123456789012345678901"));
    }

    @Test
    void testSettersUpdateValidFields() {
        Task task = new Task(
                "1",
                "Pay Bills",
                "Pay the electric bill");

        task.setName("Grocery Shopping");
        task.setDescription("Buy food for the week");

        assertEquals("Grocery Shopping", task.getName());
        assertEquals("Buy food for the week", task.getDescription());
    }

    @Test
    void testSettersRejectInvalidValues() {
        Task task = new Task(
                "1",
                "Pay Bills",
                "Pay the electric bill");

        assertThrows(
                IllegalArgumentException.class,
                () -> task.setName(null));

        assertThrows(
                IllegalArgumentException.class,
                () -> task.setName("123456789012345678901"));

        assertThrows(
                IllegalArgumentException.class,
                () -> task.setDescription(null));

        assertThrows(
                IllegalArgumentException.class,
                () -> task.setDescription(
                        "123456789012345678901234567890123456789012345678901"));
    }
}
