import java.util.Date;

/**
 * Holds the details for a single appointment.
 *
 * The checks in this class keep invalid appointment data from being stored.
 * The appointment ID is final so it stays the same after the object is made.
 */
public class Appointment {
    // The ID is set when the appointment is created and cannot be changed.
    private final String appointmentId;

    // The scheduled date and short description for the appointment.
    private Date appointmentDate;
    private String description;

    /**
     * Builds an appointment after making sure the supplied values are valid.
     *
     * @param appointmentId ID used to identify the appointment
     * @param appointmentDate date the appointment is scheduled for
     * @param description brief information about the appointment
     * @throws IllegalArgumentException if any value does not meet the rules
     */
    public Appointment(String appointmentId, Date appointmentDate,
                       String description) {
        // Check the data before saving anything to the object.
        validateAppointmentId(appointmentId);
        validateAppointmentDate(appointmentDate);
        validateDescription(description);

        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public String getDescription() {
        return description;
    }

    private static void validateAppointmentId(String appointmentId) {
        // Make sure an ID was supplied and that it fits the length limit.
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException(
                    "Appointment ID cannot be null or longer than 10 characters.");
        }
    }

    private static void validateAppointmentDate(Date appointmentDate) {
        // Only allow dates that exist and have not already passed.
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException(
                    "Appointment date cannot be null or in the past.");
        }
    }

    private static void validateDescription(String description) {
        // The description has to be present and fit within 50 characters.
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException(
                    "Description cannot be null or longer than 50 characters.");
        }
    }
}
