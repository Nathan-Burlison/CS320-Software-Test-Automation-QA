import java.util.HashMap;
import java.util.Map;

/**
 * Manages tasks while the application is running.
 *
 * A HashMap keeps each task connected to its unique ID. This milestone only
 * requires in-memory storage, so no database is needed.
 */
public class TaskService {
    // The task ID is used as the key for each stored task.
    private final Map<String, Task> tasks = new HashMap<>();

    /**
     * Adds a task when its ID is not already being used.
     *
     * @param task task to store
     * @throws IllegalArgumentException if the task is null or the ID is taken
     */
    public void addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null.");
        }

        String taskId = task.getTaskId();

        // Do not allow a second task to reuse an existing ID.
        if (tasks.containsKey(taskId)) {
            throw new IllegalArgumentException(
                    "A task with this ID already exists.");
        }

        tasks.put(taskId, task);
    }

    /**
     * Removes a task using its ID.
     *
     * @param taskId ID of the task to remove
     * @throws IllegalArgumentException if no task matches the ID
     */
    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID was not found.");
        }

        tasks.remove(taskId);
    }

    /**
     * Changes the name of an existing task.
     *
     * @param taskId ID of the task to update
     * @param name new task name
     */
    public void updateName(String taskId, String name) {
        getExistingTask(taskId).setName(name);
    }

    /**
     * Changes the description of an existing task.
     *
     * @param taskId ID of the task to update
     * @param description new task description
     */
    public void updateDescription(String taskId, String description) {
        getExistingTask(taskId).setDescription(description);
    }

    /**
     * Looks up a task by ID.
     *
     * @param taskId ID to search for
     * @return the matching task, or null if the ID is not stored
     */
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }

    private Task getExistingTask(String taskId) {
        Task task = tasks.get(taskId);

        if (task == null) {
            throw new IllegalArgumentException("Task ID was not found.");
        }

        return task;
    }
}
