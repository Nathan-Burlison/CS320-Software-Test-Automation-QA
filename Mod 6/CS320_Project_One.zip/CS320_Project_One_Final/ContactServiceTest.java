import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Tests the main behaviors provided by ContactService.
 *
 * Each test focuses on one service action so failures are easier to trace back
 * to the part of the service that caused them.
 */
class ContactServiceTest {

    private ContactService service;
    private Contact contact;

    /**
     * Creates a fresh service and valid contact before each test so tests do
     * not depend on data left behind by another test.
     */
    @BeforeEach
    void setUp() {
        service = new ContactService();
        contact = new Contact(
                "1",
                "John",
                "Smith",
                "8015551234",
                "123 Main Street");
    }

    // Add one contact and confirm it can be retrieved.
    @Test
    void testAddContact() {
        service.addContact(contact);

        assertSame(contact, service.getContact("1"));
    }

    // The service should stop a second contact from reusing an existing ID.
    @Test
    void testAddContactRequiresUniqueId() {
        service.addContact(contact);

        Contact duplicate = new Contact(
                "1",
                "Alice",
                "Jones",
                "8015555678",
                "456 Oak Street");

        assertThrows(IllegalArgumentException.class,
                () -> service.addContact(duplicate));
    }

    // Do not allow a missing contact object to be stored.
    @Test
    void testCannotAddNullContact() {
        assertThrows(IllegalArgumentException.class,
                () -> service.addContact(null));
    }

    // Remove a saved contact and make sure it is gone.
    @Test
    void testDeleteContact() {
        service.addContact(contact);
        service.deleteContact("1");

        assertNull(service.getContact("1"));
    }

    // Deleting an ID that was never stored should fail.
    @Test
    void testDeleteMissingContactThrowsException() {
        assertThrows(IllegalArgumentException.class,
                () -> service.deleteContact("missing"));
    }

    // Change only the first name for the selected contact.
    @Test
    void testUpdateFirstName() {
        service.addContact(contact);
        service.updateFirstName("1", "Johnny");

        assertEquals("Johnny", service.getContact("1").getFirstName());
    }

    // Change only the last name for the selected contact.
    @Test
    void testUpdateLastName() {
        service.addContact(contact);
        service.updateLastName("1", "Johnson");

        assertEquals("Johnson", service.getContact("1").getLastName());
    }

    // Replace the saved phone number with another valid one.
    @Test
    void testUpdatePhone() {
        service.addContact(contact);
        service.updatePhone("1", "3855559999");

        assertEquals("3855559999", service.getContact("1").getPhone());
    }

    // Replace the saved address with another valid one.
    @Test
    void testUpdateAddress() {
        service.addContact(contact);
        service.updateAddress("1", "456 Oak Avenue");

        assertEquals(
                "456 Oak Avenue",
                service.getContact("1").getAddress());
    }

    // An update should fail when the requested ID does not exist.
    @Test
    void testUpdateMissingContactThrowsException() {
        assertThrows(IllegalArgumentException.class,
                () -> service.updateFirstName("missing", "Johnny"));
    }

    // Service updates should still respect the validation inside Contact.
    @Test
    void testUpdateRejectsInvalidFieldValue() {
        service.addContact(contact);

        assertThrows(IllegalArgumentException.class,
                () -> service.updatePhone("1", "555"));
    }

    // Editing contact details should never alter the original ID.
    @Test
    void testContactIdDoesNotChangeAfterUpdates() {
        service.addContact(contact);

        service.updateFirstName("1", "Johnny");
        service.updateLastName("1", "Johnson");
        service.updatePhone("1", "3855559999");
        service.updateAddress("1", "456 Oak Avenue");

        assertEquals("1", service.getContact("1").getContactId());
    }
}
