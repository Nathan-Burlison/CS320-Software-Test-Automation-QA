/**
 * Stores the information for one task.
 *
 * Validation is handled in this class so invalid task data is rejected before
 * it can be stored. The task ID is final because it should not change after
 * the task is created.
 */
public class Task {
    // The ID is assigned once and is used to identify the task.
    private final String taskId;

    // These values may be changed later through the setter methods.
    private String name;
    private String description;

    /**
     * Creates a task after checking each required value.
     *
     * @param taskId unique ID used to identify the task
     * @param name name of the task
     * @param description details about the task
     * @throws IllegalArgumentException when a value does not meet its limit
     */
    public Task(String taskId, String name, String description) {
        validateTaskId(taskId);
        validateName(name);
        validateDescription(description);

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    /**
     * Changes the task name after checking the new value.
     *
     * @param name new task name
     */
    public void setName(String name) {
        validateName(name);
        this.name = name;
    }

    /**
     * Changes the task description after checking the new value.
     *
     * @param description new task description
     */
    public void setDescription(String description) {
        validateDescription(description);
        this.description = description;
    }

    private static void validateTaskId(String taskId) {
        // Reject an ID that is missing or longer than the allowed limit.
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException(
                    "Task ID cannot be null or longer than 10 characters.");
        }
    }

    private static void validateName(String name) {
        // A task needs a name, and the name must fit within 20 characters.
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException(
                    "Task name cannot be null or longer than 20 characters.");
        }
    }

    private static void validateDescription(String description) {
        // Keep the description present and within the required size.
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException(
                    "Task description cannot be null or longer than 50 characters.");
        }
    }
}
