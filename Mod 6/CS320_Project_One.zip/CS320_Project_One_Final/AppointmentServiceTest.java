import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Checks the add and delete behavior of AppointmentService.
 */
class AppointmentServiceTest {

    private AppointmentService service;
    private Appointment appointment;

    // Creates dates relative to today so the test data stays usable over time.
    private Date dateFromToday(int days) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, days);
        return calendar.getTime();
    }

    @BeforeEach
    void setUp() {
        // Give every test a fresh service and one valid appointment to use.
        service = new AppointmentService();
        appointment = new Appointment(
                "1",
                dateFromToday(1),
                "Annual vehicle inspection");
    }

    @Test
    void testAddAppointment() {
        // Add an appointment and make sure the same object can be retrieved.
        service.addAppointment(appointment);

        assertSame(appointment, service.getAppointment("1"));
    }

    @Test
    void testAddAppointmentRequiresUniqueId() {
        // Reusing an ID should be rejected instead of replacing the first item.
        service.addAppointment(appointment);

        Appointment duplicate = new Appointment(
                "1",
                dateFromToday(2),
                "Follow-up inspection");

        assertThrows(
                IllegalArgumentException.class,
                () -> service.addAppointment(duplicate));
    }

    @Test
    void testCannotAddNullAppointment() {
        // Make sure the service does not accept a null appointment.
        assertThrows(
                IllegalArgumentException.class,
                () -> service.addAppointment(null));
    }

    @Test
    void testDeleteAppointment() {
        // Delete a saved appointment and confirm it is no longer stored.
        service.addAppointment(appointment);
        service.deleteAppointment("1");

        assertNull(service.getAppointment("1"));
    }

    @Test
    void testDeleteMissingAppointmentThrowsException() {
        // Trying to remove an unknown ID should report an error.
        assertThrows(
                IllegalArgumentException.class,
                () -> service.deleteAppointment("missing"));
    }
}
